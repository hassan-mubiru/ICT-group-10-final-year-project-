import WishlistPage from '@/components/frontend/other/wish-list'
import React from 'react'

export default function page() {
  return (
    <div className='px-4 md:px-12 lg:px-24'>
        <WishlistPage/>
    </div>
  )
}
