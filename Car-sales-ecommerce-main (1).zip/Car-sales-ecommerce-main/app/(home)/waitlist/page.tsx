import WaitList from "@/components/Forms/WaitList";
import React from "react";

export default function page() {
  return (
    <div>
      <WaitList />
    </div>
  );
}
