"use client";

export default function Loading() {
  return <div className="loader"></div>;
}
