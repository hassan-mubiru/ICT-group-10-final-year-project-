
import CreateBannerForm from "@/components/Forms/create-banner-form";
import ProductForm from "@/components/Forms/productsForm";
import React from "react";

export default async function page() {
  
  
    
  return (
    <div className="p-8">
      <CreateBannerForm/>
    </div>
  );
}
