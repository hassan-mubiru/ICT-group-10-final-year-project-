import RoleForm from "@/components/Forms/RoleForm";

export default function page() {
  return <RoleForm />;
}
