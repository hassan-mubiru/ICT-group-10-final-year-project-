import NotAuthorized from "@/components/NotAuthorized";
import React from "react";

export default function page() {
  return (
    <div>
      <NotAuthorized />
    </div>
  );
}
