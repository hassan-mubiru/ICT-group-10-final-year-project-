"use client";

export function DataTableToolbar({ table }: { table: any }) {
  return <div className="flex items-center justify-between"></div>;
}
